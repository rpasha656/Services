import {
    TestBed, inject
} from '@angular/core/testing';
import { Component } from '@angular/core';
import { DocpubModule } from './index';
import { FileMetadataService } from './filemetadata.service';
@Component({
    selector: 'as-test',
    template: '<as-docpub></as-docpub>'
})
class TestComponent {
}

// let docpubCompiled;
// let docpubCmp: UploadComponent;

describe('UploadComponent', () => {
    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [TestComponent],
            imports: [DocpubModule],
            providers: [FileMetadataService
            ]
        });
    });

    /*it('Testing Expiration Date', async(() => {
        TestBed.compileComponents().then(() => {
            let fixture = TestBed.createComponent(DocpubComponent);
            fixture.detectChanges();

            docpubCompiled = fixture.nativeElement;
            docpubCmp = fixture.debugElement.children[0].componentInstance;
            let item = docpubCompiled.querySelectorAll('#expDate')[0];
            console.log(item.getAttribute('ng-reflect-model'));
            expect(item.getAttribute('ng-reflect-model')).toBeTruthy('ngOnInit()');
        });
    }));*/

    /*it('Testing Exceeding length', async(() => {
        TestBed.compileComponents().then(() => {
            let fixture = TestBed.createComponent(DocpubComponent);
            fixture.detectChanges();
            fixture.componentInstance.displayName = 'Name Changed';
            fixture.detectChanges();
            docpubCompiled = fixture.nativeElement;
            let displayModelName = docpubCompiled.querySelectorAll('#display')[0].getAttribute('ng-reflect-model');
            console.log(displayModelName);
            expect(displayModelName.length).toBeLessThan(40);
        });
    }));*/
    it('Testing getCategories',
        inject([FileMetadataService], (filemetadataservice) => {

            expect(filemetadataservice).toBeDefined();

            expect(filemetadataservice.getCategories());
        }));
    it('Testing  getFileMetadatalisting',
        inject([FileMetadataService], (filemetadataservice) => {

            expect(filemetadataservice).toBeDefined();

            expect(filemetadataservice.getFileMetadatalisting('HUM'));
        }));
    it('Testing  addFileMetaData',
        inject([FileMetadataService], (filemetadataservice) => {

            expect(filemetadataservice).toBeDefined();

            expect(filemetadataservice.addFileMetaData());
        }));

});
